import os
import joblib
import mysql.connector
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Conexión a la base de datos de Docker
conexion = mysql.connector.connect(
    host="127.0.0.1",
    user="root",
    password="root",
    database="atc"
)

cursor = conexion.cursor()

# Obtenemos todo menos los que tienen impagos
consulta = """
    SELECT email, categorias
    FROM emails
    WHERE client_id NOT IN (
        SELECT clientes.id 
        FROM clientes
        INNER JOIN impagos ON clientes.id = impagos.client_id
    )
"""

cursor.execute(consulta)
resultados = cursor.fetchall()

# Cerrar la conexión a la base de datos
cursor.close()
conexion.close()

texts = [item[0] for item in resultados]
categories = [item[1] for item in resultados]

X_train, X_test, y_train, y_test = train_test_split(texts, categories, test_size=0.22, random_state=42)

vectorizer = TfidfVectorizer()
X_train_tfidf = vectorizer.fit_transform(X_train)

clf = MultinomialNB()
clf.fit(X_train_tfidf, y_train)

# Directorio para almacenar los modelos
model_directory = 'app/model/'

# Crear el directorio si no existe
os.makedirs(model_directory, exist_ok=True)

# Guardar el modelo y el vectorizador TF-IDF
joblib.dump(clf, os.path.join(model_directory, 'modelo_entrenado.joblib'))
joblib.dump(vectorizer, os.path.join(model_directory, 'vectorizador_tfidf.joblib'))
