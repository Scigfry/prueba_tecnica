import joblib
import mysql.connector
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/classify-email', methods=['POST'])
def classify_email():
    try:
        data = request.get_json()

        client_id = data.get('client_id')
        fecha_envio = data.get('fecha_envio')
        email_body = data.get('email_body')
        
        # Conexión a la base de datos de Docker
        conexion = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="root",
            database="atc"
        )

        cursor = conexion.cursor()

        consulta = "SELECT COUNT(*) FROM impagos WHERE client_id = %s"  

        cursor.execute(consulta, (client_id,))
        resultado = cursor.fetchone()

        cursor.close()
        conexion.close()

        if resultado[0] > 0:
            response = {
                'exito': False,
                'razon': 'El cliente tiene impagos'
            }
        else:
            print("aaa")
            clf = joblib.load('app/model/modelo_entrenado.joblib')
            vectorizer = joblib.load('app/model/vectorizador_tfidf.joblib')
            new_text_tfidf = vectorizer.transform([email_body])
            predicciones = clf.predict(new_text_tfidf)
            
            response = {
                'exito': True,
                'prediccion': predicciones.tolist()
            }

        return jsonify(response), 200

    except Exception as e:
        return jsonify({'error': 'Error en el servidor'}), 500

if __name__ == '__main__':
    app.run(debug=True)